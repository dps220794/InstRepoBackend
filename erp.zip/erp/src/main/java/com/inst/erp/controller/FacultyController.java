package com.inst.erp.controller;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inst.erp.dao.CourseDao;
import com.inst.erp.dao.FacultyDao;
import com.inst.erp.dao.StudentDao;
import com.inst.erp.pojo.Attendence;
import com.inst.erp.pojo.Course;
import com.inst.erp.pojo.Faculty;
import com.inst.erp.pojo.Student;

@RestController
public class FacultyController {
	@Autowired
	private EntityManager manager;

	@Autowired
	private FacultyDao dao;
	@Autowired
	private CourseDao cdao;
	@Autowired
	private StudentDao sdao;

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/fregister")
	public ResponseEntity<?> registerFaculty(@RequestBody Faculty faculty) {
		System.out.println(faculty);
		dao.save(faculty);
		return new ResponseEntity<Object>("OK", HttpStatus.OK);// new ResponseEntity<String>("User created success
																// full", HttpStatus.OK);
	}

	@PostMapping("/fauthenticate")
	public ResponseEntity<?> authenticate(@RequestBody Faculty faculty) {
		Faculty temp = new Faculty();
		temp.setEmail(faculty.getEmail());
		temp.setPassword(faculty.getPassword());

		Example<Faculty> exFaculty = Example.of(temp);
		Optional<Faculty> optional = dao.findOne(exFaculty);
		// select * from User u where u.eamil=
		if (optional.isPresent()) {
			return new ResponseEntity<Faculty>(temp, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Authentication failed:invalid credential", HttpStatus.OK);

	}

	@GetMapping("/fuserprofile")
	public ResponseEntity<?> userProfile(@RequestParam Integer facultyId) {

		Faculty faculty = manager.find(Faculty.class, facultyId);
		if (faculty == null) {
			throw new EntityNotFoundException("Can't find Faculty for ID " + facultyId);
		}
		return new ResponseEntity<Faculty>(faculty, HttpStatus.OK);
	}

	@GetMapping("coursedetails")
	public ResponseEntity<List<Course>> courseDetails() {

		return new ResponseEntity<List<Course>>(cdao.getAllCourses(), HttpStatus.OK);

	}

	@PostMapping("/searchStudent")
	public ResponseEntity<?> searchStudent(@RequestParam String fname, @RequestParam String lname,
			@RequestParam String c_name) {
		Query query = manager.createQuery(
				"Select s from Student s,Course c where s.selectedCourse=c.c_id and fname=:fname and lname=:lname and c_name=:c_name");
		query.setParameter("fname", fname);
		query.setParameter("lname", lname);
		query.setParameter("c_name", c_name);

		Student stud = (Student) query.getSingleResult();
		return new ResponseEntity<Student>(stud, HttpStatus.OK);
	}
	
	  @PostMapping("/fillAttendence") 
	  public ResponseEntity<?> fillAttendence(@RequestParam Attendence a){
		  
	  }
	 
}
