package com.inst.erp.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inst.erp.dao.StudentDao;
import com.inst.erp.pojo.Student;

@RestController
public class StudentController {
@Autowired
private StudentDao dao;
@CrossOrigin(origins = "http://localhost:4200")
@PostMapping("/sregister")
public ResponseEntity<?> registerStudent(@RequestBody Student student){
	System.out.println(student);
	dao.save(student);
	return new ResponseEntity<Object>("OK",HttpStatus.OK);// new ResponseEntity<String>("User created success full", HttpStatus.OK);
}

@PostMapping("/sauthenticate")
public ResponseEntity<?> authenticate(@RequestBody Student student){
	Student temp=new Student();
	temp.setEmail(student.getEmail());
	temp.setPassword(student.getPassword());

	Example<Student> exStudent=Example.of(temp);
	Optional<Student> optional=dao.findOne(exStudent);
	//select * from User u where u.eamil=
	if(optional.isPresent()) {
		return new ResponseEntity<Student>(temp,HttpStatus.OK);
	}
	return new ResponseEntity<String>("Authentication failed:invalid credential", HttpStatus.OK);

}
	/*
	 * @PostMapping("/ssearch") public ResponseEntity<?> searchStudent(@RequestBody
	 * Student student){
	 * 
	 * return ResponseEntity<Student>(HttpStatus.OK); }
	 */
}
