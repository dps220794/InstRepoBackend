package com.inst.erp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inst.erp.pojo.Attendence;


public interface AttendenceDao extends JpaRepository<Attendence, Integer> {

}
