package com.inst.erp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.inst.erp.pojo.Course;
import com.inst.erp.pojo.Student;
@Repository
public interface CourseDao extends JpaRepository<Course, Integer>{
	@Query("select c from Course c")
	List<Course> getAllCourses();

}
