package com.inst.erp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.inst.erp.pojo.Subject;
@Repository
public interface SubjectDao extends JpaRepository<Subject, Integer>{

}
