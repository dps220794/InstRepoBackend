package com.inst.erp.pojo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Attendence {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private LocalDate lectureDate;
	private String c_name;
	private String subject;
	private boolean isPresent;
	@OneToOne(mappedBy="isPresent",cascade = CascadeType.ALL)
	private Student stud;
	
	public Attendence(LocalDate lectureDate, String c_name, String subject, boolean isPresent,Student stud) {
		super();
		this.lectureDate = lectureDate;
		this.c_name = c_name;
		this.subject = subject;
		this.isPresent = isPresent;
		this.stud = stud;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getLectureDate() {
		return lectureDate;
	}

	public void setLectureDate(LocalDate lectureDate) {
		this.lectureDate = lectureDate;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public boolean isisPresent() {
		return isPresent;
	}

	public void setisPresent(boolean isPresent) {
		this.isPresent = isPresent;
	}

	public Student getStud() {
		return stud;
	}

	public void setStud(Student stud) {
		this.stud = stud;
	}

	@Override
	public String toString() {
		return "Attendence [id=" + id + ", lectureDate=" + lectureDate + ", c_name=" + c_name + ", subject=" + subject
				+ ", isPresent=" + isPresent + ", stud=" + stud + "]";
	}
	

}
